/// ============================================================================
/// [todo.dart] - Todo 데이터 모델 클래스
/// ============================================================================
/// Hive 로컬 데이터베이스에 저장되는 Todo 객체의 구조를 정의합니다.
///
/// [핵심 개념]
/// - @HiveType(typeId: 1) : Hive가 이 클래스를 식별하기 위한 고유 ID
/// - @HiveField(n)        : 각 필드에 고유 번호를 부여하여 직렬화/역직렬화 시 매핑
/// - part 'todo.g.dart'   : 코드 생성기(build_runner)가 TypeAdapter를 자동 생성
///
/// [주의사항]
/// - typeId는 프로젝트 전체에서 중복되면 안 됩니다.
/// - HiveField 번호는 한 번 정하면 변경하면 안 됩니다 (기존 데이터 호환성 유지).
/// - 필드를 추가할 때는 새로운 HiveField 번호를 사용해야 합니다.
/// ============================================================================

import 'package:hive_flutter/hive_flutter.dart';

/// todo.g.dart 파일을 이 파일의 일부로 포함합니다.
/// build_runner가 TodoAdapter 클래스를 자동 생성해 줍니다.
/// 명령어: flutter packages pub run build_runner build
part 'todo.g.dart';

/// Hive에 저장할 수 있는 Todo 데이터 모델
/// typeId: 1 → Hive 내부에서 이 타입을 구분하기 위한 고유 식별자
@HiveType(typeId: 1)
class Todo {
  /// [필드 0] 고유 번호 - 밀리초 타임스탬프를 사용하여 유니크한 값을 생성합니다.
  /// Hive Box에서 key로도 사용됩니다 (put("${todo.no}", todo)).
  @HiveField(0)
  final int no;

  /// [필드 1] 할 일 내용 - 사용자가 입력한 텍스트
  @HiveField(1)
  final String content;

  /// [필드 2] 태그 (색상 인덱스) - TodoColor 클래스의 색상 목록 인덱스에 대응합니다.
  /// 0~9 사이의 값으로, 각 숫자가 특정 색상을 나타냅니다.
  @HiveField(2)
  final int tag;

  /// [필드 3] 완료 여부 - true이면 체크 완료, false이면 미완료 상태입니다.
  /// 체크박스를 눌러 토글할 수 있습니다.
  @HiveField(3)
  final bool isCheck;

  /// [필드 4] 생성 일시 - Todo가 처음 만들어진 시간
  @HiveField(4)
  final DateTime createdAt;

  /// [필드 5] 수정 일시 - Todo가 마지막으로 수정된 시간
  /// 정렬 기준으로 사용됩니다 (최신 수정 순).
  @HiveField(5)
  final DateTime updatedAt;

  /// 기본 생성자 - 모든 필드를 required로 받습니다.
  /// const로 선언하여 컴파일 타임 상수 생성이 가능합니다.
  const Todo({
    required this.no,
    required this.content,
    required this.tag,
    required this.isCheck,
    required this.createdAt,
    required this.updatedAt,
  });

  /// [팩토리 생성자] Todo.create - 새로운 Todo를 생성할 때 사용합니다.
  /// - no: DateTime.now().millisecondsSinceEpoch로 유니크한 ID를 자동 생성
  /// - content: 사용자가 입력한 할 일 내용
  /// - current: 선택한 태그(색상) 인덱스
  /// - isCheck: 새로 생성된 Todo는 항상 미완료(false) 상태
  /// - createdAt, updatedAt: 현재 시간으로 동일하게 설정
  factory Todo.create(String content, int current) => Todo(
        no: DateTime.now().millisecondsSinceEpoch,
        content: content,
        tag: current,
        isCheck: false,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

  /// [copyWith 메서드] - 불변(immutable) 객체의 일부 필드만 변경한 새 객체를 생성합니다.
  /// 전달하지 않은 필드는 기존 값을 유지합니다.
  /// 예: todo.copyWith(isCheck: true) → isCheck만 true로 변경된 새 Todo 반환
  Todo copyWith({
    final int? no,
    final String? content,
    final int? tag,
    final bool? isCheck,
    final DateTime? createdAt,
    final DateTime? updatedAt,
  }) {
    return Todo(
      no: no ?? this.no,
      content: content ?? this.content,
      tag: tag ?? this.tag,
      isCheck: isCheck ?? this.isCheck,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// 디버깅용 toString 오버라이드 - 객체의 모든 필드 값을 문자열로 출력합니다.
  @override
  String toString() =>
      "Todo(no: $no, content: $content, tag: $tag, isCheck: $isCheck, createdAt: $createdAt, updatedAt: $updatedAt)";
}
