/// ============================================================================
/// [todo_edit_widget.dart] - Todo 생성/수정 위젯 (BottomSheet)
/// ============================================================================
/// BottomSheet 형태로 표시되며, 새 Todo를 생성하거나 기존 Todo를 수정합니다.
///
/// [UI 구성]
/// 1. 상단 헤더: "CREATE TODO" 또는 "UPDATE TODO" 타이틀 + SAVE/CHANGE 버튼
/// 2. content 입력 필드: 할 일 내용을 입력하는 TextFormField
/// 3. tag 선택 영역: 10가지 색상 중 하나를 선택하는 색상 팔레트
///
/// [생성 모드 vs 수정 모드]
/// - widget.update가 null → 생성 모드 (빈 입력 필드, 타이틀: "CREATE TODO")
/// - widget.update가 not null → 수정 모드 (기존 값 표시, 타이틀: "UPDATE TODO")
///
/// [데이터 반환 방식]
/// Navigator.pop()으로 Todo 객체를 반환합니다.
/// - 생성 모드: Todo.create()로 새 객체 생성하여 반환
/// - 수정 모드: widget.update!.copyWith()으로 변경된 필드만 업데이트하여 반환
/// 반환된 값은 HomePage의 _updated() 메서드에서 처리됩니다.
/// ============================================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hive_sample/_sample/todo.dart';
import 'package:flutter_hive_sample/_sample/todo_color.dart';

/// TodoEditWidget - Todo 생성 및 수정을 위한 StatefulWidget
/// [update] 파라미터가 null이면 생성 모드, 값이 있으면 수정 모드로 동작합니다.
class TodoEditWidget extends StatefulWidget {
  /// 수정할 기존 Todo 객체 (null이면 새로 생성)
  final Todo? update;
  const TodoEditWidget({
    super.key,
    required this.update,
  });

  @override
  State<TodoEditWidget> createState() => _TodoEditWidgetState();
}

class _TodoEditWidgetState extends State<TodoEditWidget> {
  /// 할 일 내용 입력을 위한 TextEditingController
  /// 수정 모드에서는 기존 content로 초기화됩니다.
  late TextEditingController controller;

  /// 현재 선택된 태그(색상) 인덱스를 관리하는 ValueNotifier
  /// 값이 변경되면 ValueListenableBuilder가 색상 팔레트 UI를 자동 갱신합니다.
  ValueNotifier<int> current = ValueNotifier(0);

  /// 선택 가능한 색상 목록
  List<Color> colors = [];

  /// 색상 선택 시 호출되는 메서드 - current ValueNotifier의 값을 변경합니다.
  void onChanged(int index) => current.value = index;

  @override
  void initState() {
    super.initState();

    /// 수정 모드인 경우: 기존 Todo의 content와 tag 값으로 초기화
    if (widget.update != null) {
      controller = TextEditingController(text: widget.update!.content);
      current.value = widget.update!.tag;
    } else {
      /// 생성 모드인 경우: 빈 TextEditingController로 초기화
      controller = TextEditingController();
    }

    /// TodoColor에서 10가지 색상 목록을 가져옵니다.
    colors = TodoColor.setColors();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      /// 빈 영역 탭 시 키보드를 숨깁니다.
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Container(
        color: Colors.transparent,
        width: MediaQuery.of(context).size.width,

        /// 시트의 높이: 전체 화면 높이 - 상단 툴바 높이
        height: MediaQuery.of(context).size.height - (kToolbarHeight),
        child: Column(
          children: [
            /// ─────────────────────────────────────────────────
            /// [상단 헤더 영역] - 타이틀과 저장 버튼
            /// ─────────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.only(top: 16),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              height: 60,
              color: Colors.transparent,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  /// 타이틀: 생성 모드면 "CREATE TODO", 수정 모드면 "UPDATE TODO"
                  Text(
                    widget.update == null ? "CREATE TODO" : "UPDATE TODO",
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                      fontSize: 18,
                    ),
                  ),

                  /// [저장/변경 버튼] - 탭하면 Todo 객체를 생성/수정하여 반환합니다.
                  GestureDetector(
                    onTap: () {
                      /// 햅틱 피드백으로 터치 반응을 줍니다.
                      HapticFeedback.mediumImpact();

                      /// Navigator.pop()으로 Todo 객체를 반환합니다.
                      /// 이 값은 HomePage의 _showEditSheet().then(_updated)로 전달됩니다.
                      Navigator.of(context).pop(
                        widget.update == null
                            /// 생성 모드: Todo.create()로 새 Todo 객체 생성
                            /// - controller.text: 입력된 할 일 내용
                            /// - current.value: 선택된 태그(색상) 인덱스
                            ? Todo.create(controller.text, current.value)
                            /// 수정 모드: 기존 Todo의 content와 tag만 변경
                            /// copyWith()을 사용하여 나머지 필드는 유지합니다.
                            /// (주의: updatedAt이 갱신되지 않는 점은 잠재적 개선 포인트)
                            : widget.update!.copyWith(
                                content: controller.text, tag: current.value),
                      );
                    },
                    child: Text(
                      widget.update == null ? "SAVE" : "CHAGNGE",
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: Colors.red,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            /// ─────────────────────────────────────────────────
            /// [content 입력 필드] - 할 일 내용 입력
            /// ─────────────────────────────────────────────────
            /// _form() 헬퍼 메서드를 사용하여 레이블과 함께 배치합니다.
            _form(
              "content",
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: Colors.black,
                      width: 2,
                    )),
                child: TextFormField(
                  controller: controller,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontSize: 16),
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.symmetric(horizontal: 12),

                    /// 기본 밑줄 테두리를 제거하여 깔끔한 UI를 유지합니다.
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                  ),
                ),
              ),
            ),

            /// ─────────────────────────────────────────────────
            /// [tag 선택 영역] - 색상 팔레트
            /// ─────────────────────────────────────────────────
            /// ValueListenableBuilder로 현재 선택된 색상(current)의 변경을 감지하여
            /// 선택된 색상에만 체크 아이콘과 테두리를 표시합니다.
            _form(
              "tag",
              ValueListenableBuilder<int>(
                  valueListenable: current,
                  builder: (context, value, child) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      child: Wrap(
                        /// 가로 간격
                        spacing: 8,
                        /// 줄바꿈 시 세로 간격
                        runSpacing: 10,
                        children: [
                          /// 10가지 색상을 순회하며 색상 선택 버튼을 생성합니다.
                          ...List.generate(
                            colors.length,
                            (index) => GestureDetector(
                              onTap: () {
                                HapticFeedback.mediumImpact();
                                /// 선택된 색상 인덱스를 변경합니다.
                                onChanged(index);
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    /// 현재 선택된 색상에만 진한 회색 테두리를 표시합니다.
                                    border: value == index
                                        ? Border.all(
                                            color: const Color.fromRGBO(
                                                91, 91, 91, 1),
                                            width: 2,
                                          )
                                        : null,
                                    borderRadius: BorderRadius.circular(8),

                                    /// 선택된 색상: 원래 색상 (100% 불투명)
                                    /// 선택되지 않은 색상: 60% 불투명도로 연하게 표시
                                    color: value == index
                                        ? colors[index]
                                        : colors[index].withOpacity(0.6),
                                  ),
                                  child: Visibility(
                                    /// 선택된 색상에만 체크 아이콘(✓)을 표시합니다.
                                    visible: value == index,
                                    child: const Icon(
                                      Icons.check,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    );
                  }),
            ),
          ],
        ),
      ),
    );
  }

  /// [_form] - 레이블과 입력 위젯을 세로로 배치하는 헬퍼 메서드
  ///
  /// [매개변수]
  /// - content: 레이블 텍스트 (예: "content", "tag")
  /// - child: 레이블 아래에 표시할 위젯 (TextFormField, 색상 팔레트 등)
  ///
  /// 재사용 가능한 폼 레이아웃을 제공하여 코드 중복을 줄입니다.
  Container _form(
    String content,
    Widget child,
  ) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 레이블 텍스트 (회색)
          Container(
            margin: const EdgeInsets.only(top: 16, bottom: 8),
            child: Text(
              content,
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(115, 115, 115, 1)),
            ),
          ),

          /// 레이블 아래에 표시되는 실제 입력 위젯
          child,
        ],
      ),
    );
  }
}
