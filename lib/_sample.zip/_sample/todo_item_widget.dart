/// ============================================================================
/// [todo_item_widget.dart] - Todo 아이템 위젯 (목록의 개별 항목)
/// ============================================================================
/// Todo 목록에서 각 항목을 표시하는 위젯입니다.
///
/// [UI 구성] (가로 Row 레이아웃)
/// ┌──────────────────────────────────────────┐
/// │ [☐ 체크박스] [● 색상태그] [할 일 내용     ] │
/// │                         [2024. 01. 15   ] │
/// │                         [(수정됨)        ] │
/// └──────────────────────────────────────────┘
///
/// [사용자 인터랙션]
/// - 탭 (onTap): Todo 수정을 위한 BottomSheet를 엽니다.
/// - 길게 누르기 (onLongPress): 삭제 옵션 시트를 표시합니다.
///   → "Delete": 해당 Todo만 삭제
///   → "All": 전체 Todo 삭제
/// - 체크박스 탭 (onChecked): 완료/미완료 상태를 토글합니다.
///
/// [StatelessWidget을 사용하는 이유]
/// 이 위젯은 자체 상태를 가지지 않습니다.
/// 모든 데이터(todo)와 이벤트 핸들러(onChecked, onTap, onDeleted)를
/// 부모 위젯(HomePage)으로부터 전달받아 사용합니다.
/// ============================================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hive_sample/_sample/todo.dart';
import 'package:flutter_hive_sample/_sample/todo_color.dart';

/// TodoItemWidget - Todo 목록의 개별 아이템을 표시하는 위젯
class TodoItemWidget extends StatelessWidget {
  /// 표시할 Todo 데이터
  final Todo todo;

  /// 체크박스 상태 변경 콜백 - isCheck가 토글된 Todo 객체를 전달합니다.
  final Function(Todo) onChecked;

  /// 아이템 탭 콜백 - 수정 시트를 열기 위해 호출됩니다.
  final Function() onTap;

  /// 삭제 콜백 - int?(Todo의 no)를 전달합니다.
  /// no가 null이면 전체 삭제, null이 아니면 해당 항목만 삭제합니다.
  final Function(int?) onDeleted;

  const TodoItemWidget({
    super.key,
    required this.todo,
    required this.onChecked,
    required this.onTap,
    required this.onDeleted,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      /// [탭] - 햅틱 피드백 후 수정 시트를 엽니다.
      onTap: () {
        HapticFeedback.mediumImpact();
        onTap();
      },

      /// [길게 누르기] - 삭제 옵션 BottomSheet를 표시합니다.
      onLongPress: () {
        HapticFeedback.mediumImpact();
        _showDeleteSheet(context, onDeleted);
      },
      child: Container(
        margin: const EdgeInsets.only(left: 20, right: 20, top: 12, bottom: 22),
        color: Colors.transparent,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// ─────────────────────────────────────────────────
            /// [체크박스 영역] - 완료/미완료 상태 토글
            /// ─────────────────────────────────────────────────
            GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();

                /// copyWith를 사용하여 isCheck만 반전시킨 새 Todo 객체를 생성하고
                /// onChecked 콜백으로 부모(HomePage)에 전달합니다.
                onChecked(todo.copyWith(isCheck: !todo.isCheck));
              },
              child: Icon(
                /// 완료: 체크된 박스 아이콘 / 미완료: 빈 박스 아이콘
                todo.isCheck ? Icons.check_box : Icons.check_box_outline_blank,
                color: const Color.fromRGBO(115, 115, 115, 1),
                size: 32,
              ),
            ),

            /// ─────────────────────────────────────────────────
            /// [색상 태그 원형 표시] - Todo의 tag 값에 대응하는 색상
            /// ─────────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.only(top: 4, left: 4),
              width: 25,
              height: 25,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),

                /// TodoColor.colorOf()를 통해 tag 인덱스에 해당하는 색상을 가져옵니다.
                color: TodoColor.colorOf(todo.tag),
              ),
            ),

            /// ─────────────────────────────────────────────────
            /// [텍스트 영역] - 할 일 내용 + 날짜 표시
            /// ─────────────────────────────────────────────────
            Expanded(
              child: Container(
                margin: const EdgeInsets.only(left: 8, top: 2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// [할 일 내용]
                    /// 내용이 비어있으면 "none content"을 회색으로 표시하고,
                    /// 내용이 있으면 흰색 볼드체로 표시합니다.
                    Text(
                      todo.content.isEmpty ? "none content" : todo.content,
                      style: todo.content.isEmpty
                          ? const TextStyle(
                              color: Color.fromRGBO(115, 115, 115, 1),
                              fontSize: 16,
                            )
                          : const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                    ),
                    const SizedBox(height: 8),

                    /// [날짜 표시]
                    /// updatedAt에서 날짜 부분(YYYY-MM-DD)만 추출하여
                    /// "YYYY. MM. DD" 형식으로 표시합니다.
                    /// 생성일과 수정일이 다르면 "(수정됨)" 텍스트를 추가 표시합니다.
                    RichText(
                        text: TextSpan(
                      text: todo.updatedAt
                          .toString()
                          .substring(0, 10) // "YYYY-MM-DD" 부분만 추출
                          .replaceAll("-", ". "), // "-"를 ". "으로 변환
                      style: const TextStyle(
                        color: Color.fromRGBO(215, 215, 215, 1),
                        fontSize: 12,
                      ),
                      children: [
                        /// 생성일과 수정일이 다를 경우에만 "(수정됨)" 표시
                        if (todo.createdAt != todo.updatedAt) ...[
                          const TextSpan(
                              text: "  (수정됨)",
                              style: TextStyle(
                                fontSize: 10,
                                color: Color.fromRGBO(115, 115, 115, 1),
                              )),
                        ],
                      ],
                    )),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// [_showDeleteSheet] - 삭제 옵션 BottomSheet를 표시합니다.
  ///
  /// [삭제 옵션]
  /// 1. "Delete" (index == 0): 현재 Todo만 삭제 → onTap(todo.no) 호출
  /// 2. "All" (index == 1): 전체 Todo 삭제 → onTap(null) 호출
  ///
  /// onTap에 전달되는 값에 따라 HomePage의 _onDeleted에서 처리 방식이 달라집니다.
  /// - todo.no (int): 해당 항목만 삭제
  /// - null: _box.clear()로 전체 삭제
  _showDeleteSheet(
    BuildContext context,
    Function(int?) onTap,
  ) =>
      showModalBottomSheet(
        context: context,
        builder: (context) => SizedBox(
          width: MediaQuery.of(context).size.width,

          /// 높이: 옵션 2개(50px * 2 = 100px) + 상단 여백(12px) + 하단 SafeArea
          height: 112 + MediaQuery.of(context).padding.bottom,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// 2개의 삭제 옵션 버튼을 생성합니다.
              ...List.generate(
                2,
                (index) => GestureDetector(
                  onTap: () {
                    HapticFeedback.mediumImpact();

                    /// index == 0: "Delete" → 해당 Todo의 no를 전달
                    /// index == 1: "All" → null을 전달 (전체 삭제)
                    onTap(index == 0 ? todo.no : null);

                    /// BottomSheet를 닫습니다.
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    margin: EdgeInsets.only(
                        left: 20, right: 20, top: index == 0 ? 12 : 0),
                    alignment: Alignment.centerLeft,
                    color: Colors.transparent,
                    height: 50,
                    child: Text(index == 0 ? "Delete" : "All",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,

                          /// "Delete"는 검은색, "All"은 빨간색(경고)으로 표시
                          color: index == 0 ? Colors.black : Colors.red,
                          fontSize: 16,
                        )),
                  ),
                ),
              )
            ],
          ),
        ),
      );
}
