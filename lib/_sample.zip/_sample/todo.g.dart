/// ============================================================================
/// [todo.g.dart] - Hive TypeAdapter 자동 생성 파일
/// ============================================================================
/// 이 파일은 build_runner에 의해 자동 생성됩니다.
/// 명령어: flutter packages pub run build_runner build
///
/// [역할]
/// Todo 객체를 Hive의 바이너리 형식으로 직렬화(write)하고,
/// 바이너리 데이터를 다시 Todo 객체로 역직렬화(read)하는 어댑터입니다.
///
/// [주의] 이 파일을 수동으로 수정하면 안 됩니다!
/// todo.dart의 @HiveType, @HiveField 어노테이션을 수정한 후
/// build_runner를 다시 실행하면 이 파일이 재생성됩니다.
/// ============================================================================

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'todo.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

/// TodoAdapter - Todo 객체의 Hive 직렬화/역직렬화를 담당하는 어댑터 클래스
/// TypeAdapter<Todo>를 상속하여 read()와 write() 메서드를 구현합니다.
class TodoAdapter extends TypeAdapter<Todo> {
  /// typeId: 1 → todo.dart의 @HiveType(typeId: 1)과 동일한 값
  /// Hive 내부에서 이 어댑터가 어떤 타입을 담당하는지 식별합니다.
  @override
  final int typeId = 1;

  /// [read 메서드] - Hive에서 바이너리 데이터를 읽어 Todo 객체로 변환합니다.
  /// BinaryReader가 저장된 바이트를 순서대로 읽어들입니다.
  ///
  /// 동작 순서:
  /// 1. 필드 개수(numOfFields)를 읽습니다.
  /// 2. 각 필드의 번호(key)와 값(value)을 Map으로 구성합니다.
  /// 3. 필드 번호에 맞는 값을 Todo 생성자에 전달하여 객체를 생성합니다.
  @override
  Todo read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Todo(
      no: fields[0] as int,           // 필드 0: 고유 번호
      content: fields[1] as String,    // 필드 1: 할 일 내용
      tag: fields[2] as int,           // 필드 2: 태그 (색상 인덱스)
      isCheck: fields[3] as bool,      // 필드 3: 완료 여부
      createdAt: fields[4] as DateTime, // 필드 4: 생성 일시
      updatedAt: fields[5] as DateTime, // 필드 5: 수정 일시
    );
  }

  /// [write 메서드] - Todo 객체를 바이너리 데이터로 변환하여 Hive에 저장합니다.
  /// BinaryWriter를 사용하여 각 필드를 순서대로 씁니다.
  ///
  /// 동작 순서:
  /// 1. 총 필드 개수(6)를 먼저 기록합니다.
  /// 2. 각 필드마다 [필드 번호 → 필드 값] 순서로 기록합니다.
  @override
  void write(BinaryWriter writer, Todo obj) {
    writer
      ..writeByte(6)           // 총 필드 개수: 6개
      ..writeByte(0)           // 필드 번호 0
      ..write(obj.no)          // → no 값 기록
      ..writeByte(1)           // 필드 번호 1
      ..write(obj.content)     // → content 값 기록
      ..writeByte(2)           // 필드 번호 2
      ..write(obj.tag)         // → tag 값 기록
      ..writeByte(3)           // 필드 번호 3
      ..write(obj.isCheck)     // → isCheck 값 기록
      ..writeByte(4)           // 필드 번호 4
      ..write(obj.createdAt)   // → createdAt 값 기록
      ..writeByte(5)           // 필드 번호 5
      ..write(obj.updatedAt);  // → updatedAt 값 기록
  }

  /// hashCode 오버라이드 - typeId를 기반으로 해시코드를 생성합니다.
  @override
  int get hashCode => typeId.hashCode;

  /// == 오버라이드 - 같은 typeId를 가진 TodoAdapter는 동일한 것으로 판단합니다.
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TodoAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
