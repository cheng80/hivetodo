/// ============================================================================
/// [todo_color.dart] - Todo 태그 색상 관리 유틸리티 클래스
/// ============================================================================
/// Todo 항목에 부여할 수 있는 색상 태그를 관리합니다.
/// 총 10가지 색상을 제공하며, 인덱스(0~9)로 색상을 선택할 수 있습니다.
///
/// [사용처]
/// - TodoEditWidget: 새 Todo 생성/수정 시 색상 선택 UI에 사용
/// - TodoItemWidget: Todo 목록에서 각 항목의 태그 색상 표시에 사용
///
/// [색상 인덱스 매핑]
/// 0: 빨강(red)         5: 딥 오렌지(deepOrange)
/// 1: 앰버(amber)       6: 핑크(pink)
/// 2: 보라(purpleAccent) 7: 틸(teal)
/// 3: 라이트블루(lightBlue) 8: 인디고(indigoAccent)
/// 4: 파랑(blue)        9: 초록(green)
/// 그 외: 회색(91, 91, 91) - 기본값
/// ============================================================================

import 'package:flutter/material.dart';

/// TodoColor - Todo 태그 색상을 관리하는 유틸리티 클래스
/// 인스턴스 생성 없이 static 메서드로만 사용합니다.
class TodoColor {
  /// [setColors] - 선택 가능한 전체 색상 목록을 리스트로 반환합니다.
  /// TodoEditWidget에서 색상 선택 UI를 구성할 때 사용됩니다.
  /// 반환되는 리스트의 인덱스가 곧 Todo 모델의 tag 값이 됩니다.
  static List<Color> setColors() => [
        Colors.red,          // 인덱스 0
        Colors.amber,        // 인덱스 1
        Colors.purpleAccent, // 인덱스 2
        Colors.lightBlue,    // 인덱스 3
        Colors.blue,         // 인덱스 4
        Colors.deepOrange,   // 인덱스 5
        Colors.pink,         // 인덱스 6
        Colors.teal,         // 인덱스 7
        Colors.indigoAccent, // 인덱스 8
        Colors.green,        // 인덱스 9
      ];

  /// [colorOf] - 주어진 인덱스에 해당하는 색상을 반환합니다.
  /// TodoItemWidget에서 각 Todo 항목의 태그 색상을 표시할 때 사용됩니다.
  /// Dart 3의 switch 표현식(expression)을 사용하여 간결하게 작성되었습니다.
  /// 인덱스가 0~9 범위를 벗어나면 회색(기본값)을 반환합니다.
  static Color colorOf(int index) => switch (index) {
        0 => Colors.red,
        1 => Colors.amber,
        2 => Colors.purpleAccent,
        3 => Colors.lightBlue,
        4 => Colors.blue,
        5 => Colors.deepOrange,
        6 => Colors.pink,
        7 => Colors.teal,
        8 => Colors.indigoAccent,
        9 => Colors.green,
        _ => const Color.fromRGBO(91, 91, 91, 1), // 기본값: 회색
      };
}
