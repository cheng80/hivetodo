/// ============================================================================
/// [home_page.dart] - 메인 홈 화면 (Todo 목록 페이지)
/// ============================================================================
/// 이 파일은 앱의 메인 화면으로, Hive DB에서 Todo 목록을 불러와 표시합니다.
///
/// [주요 기능]
/// 1. Hive Box에서 Todo 목록을 로드하여 화면에 표시
/// 2. 새로운 Todo 추가 (AppBar의 + 버튼)
/// 3. 기존 Todo 수정 (아이템 탭)
/// 4. Todo 완료 상태 토글 (체크박스)
/// 5. Todo 삭제 (길게 누르기 → 삭제 시트)
/// 6. 목록 정렬: 미완료 항목이 위, 완료 항목이 아래, 각각 최신 수정순
///
/// [상태 관리 방식]
/// ValueNotifier<List<Todo>>를 사용하여 상태를 관리합니다.
/// _todos 값이 변경되면 ValueListenableBuilder가 자동으로 UI를 갱신합니다.
///
/// [Hive 사용 패턴]
/// - _box.values → Box에 저장된 모든 Todo를 가져옴
/// - _box.put(key, value) → 특정 키에 Todo를 저장 (생성/수정)
/// - _box.delete(key) → 특정 키의 Todo를 삭제
/// - _box.clear() → Box의 모든 데이터를 삭제 (전체 삭제)
/// ============================================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hive_sample/_sample/todo.dart';
import 'package:flutter_hive_sample/_sample/todo_edit_widget.dart';
import 'package:flutter_hive_sample/_sample/todo_item_widget.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// HomePage - Todo 목록을 표시하는 메인 화면 위젯
/// StatefulWidget으로 구현되어 Todo 목록의 상태 변화를 관리합니다.
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  /// Hive Box 참조 - main.dart에서 이미 열어둔 "todo" Box를 가져옵니다.
  /// 이 Box를 통해 Todo 데이터의 CRUD(생성, 읽기, 수정, 삭제) 작업을 수행합니다.
  late Box<Todo> _box;

  /// Todo 목록 상태를 관리하는 ValueNotifier
  /// 값이 변경되면 ValueListenableBuilder가 감지하여 UI를 자동 갱신합니다.
  /// setState() 없이도 특정 위젯만 효율적으로 리빌드할 수 있습니다.
  final ValueNotifier<List<Todo>> _todos = ValueNotifier([]);

  @override
  void initState() {
    super.initState();

    /// main.dart에서 이미 열어둔 "todo" Box의 참조를 가져옵니다.
    /// Hive.box<Todo>("todo")는 이미 열려있는 Box를 반환합니다 (다시 열지 않음).
    _box = Hive.box<Todo>("todo");

    /// Hive Box에서 초기 데이터를 로드합니다.
    _init();
  }

  /// [_init] - Hive Box에서 저장된 모든 Todo를 로드하고 정렬합니다.
  /// _box.values는 Box에 저장된 모든 Todo 객체를 Iterable로 반환합니다.
  /// .map((e) => e)를 통해 새로운 리스트를 생성합니다.
  void _init() async {
    _todos.value = _box.values.map((e) => e).toList();
    _sort();
  }

  /// [_updated] - Todo가 생성되거나 수정된 후 호출되는 콜백 메서드
  /// BottomSheet(TodoEditWidget)에서 반환된 Todo 객체를 처리합니다.
  ///
  /// [동작 흐름]
  /// 1. BottomSheet에서 null이 아닌 Todo 객체가 반환되면 실행
  /// 2. Hive Box에 Todo를 저장 (put) - key는 todo.no를 문자열로 변환
  /// 3. 기존 목록에서 같은 no를 가진 Todo를 검색
  ///    - 없으면 (i < 0): 새 Todo이므로 목록 끝에 추가
  ///    - 있으면 (i >= 0): 기존 Todo이므로 해당 위치에서 삭제 후 다시 삽입 (수정)
  /// 4. 정렬 수행
  void _updated(Object? value) async {
    if (value != null) {
      Todo todo = value as Todo;

      /// Hive Box에 저장 - key: "todo.no", value: Todo 객체
      /// put()은 key가 이미 존재하면 덮어쓰기(update), 없으면 새로 생성(insert)
      _box.put("${todo.no}", todo);

      /// 현재 목록에서 같은 no를 가진 Todo의 인덱스를 찾습니다.
      int i = _todos.value.indexWhere((e) => e.no == todo.no);

      if (i < 0) {
        /// 새로운 Todo인 경우: 목록에 추가
        _todos.value = List.from(_todos.value)..add(todo);
      } else {
        /// 기존 Todo 수정인 경우: 해당 인덱스에서 삭제 후 같은 위치에 수정된 객체 삽입
        _todos.value = List.from(_todos.value)
          ..removeAt(i)
          ..insert(i, todo);
      }

      /// 정렬 수행
      _sort();
    }
  }

  /// [_sort] - Todo 목록을 정렬합니다.
  ///
  /// [정렬 규칙]
  /// 1. 미완료 항목(isCheck == false)이 상단에 위치
  /// 2. 완료 항목(isCheck == true)이 하단에 위치
  /// 3. 각 그룹 내에서는 수정일(updatedAt) 기준 내림차순 (최신이 위)
  ///
  /// 이렇게 하면 사용자가 아직 해야 할 일을 먼저 보고,
  /// 완료된 항목은 아래쪽에서 확인할 수 있습니다.
  void _sort() {
    _todos.value = [
      /// 미완료 항목: isCheck가 false인 것만 필터링 후 수정일 내림차순 정렬
      ..._todos.value.where((e) => !e.isCheck).toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt)),

      /// 완료 항목: isCheck가 true인 것만 필터링 후 수정일 내림차순 정렬
      ..._todos.value.where((e) => e.isCheck).toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt)),
    ];
  }

  /// [_onChecked] - Todo의 완료 상태가 변경되었을 때 호출됩니다.
  /// 체크박스를 탭하면 TodoItemWidget에서 이 메서드를 호출합니다.
  ///
  /// [동작]
  /// 1. Hive Box에 변경된 Todo를 저장 (isCheck 토글 반영)
  /// 2. 메모리 목록에서도 해당 인덱스의 항목을 교체
  /// 3. 정렬 수행 (완료/미완료 그룹 재배치)
  void _onChecked(Todo todo, int index) {
    _box.put("${todo.no}", todo);
    _todos.value = List.from(_todos.value)
      ..removeAt(index)
      ..insert(index, todo);
    _sort();
  }

  /// [_onDeleted] - Todo 삭제 처리 메서드
  ///
  /// [매개변수] no: 삭제할 Todo의 고유번호
  /// - no가 null이 아닌 경우: 해당 no의 Todo 하나만 삭제
  /// - no가 null인 경우: 모든 Todo를 삭제 (전체 초기화)
  ///
  /// Hive Box와 메모리 목록 양쪽에서 모두 삭제합니다.
  void _onDeleted(int? no) {
    if (no == null) {
      /// 전체 삭제: Box의 모든 데이터를 지우고 메모리 목록도 비웁니다.
      _box.clear();
      _todos.value = [];
    } else {
      /// 단일 삭제: 해당 no를 key로 사용하여 Box에서 삭제하고,
      /// 메모리 목록에서도 같은 no를 가진 항목을 제거합니다.
      _box.delete("$no");
      _todos.value = List.from(_todos.value)..removeWhere((e) => e.no == no);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      /// 빈 영역을 탭하면 키보드를 숨깁니다 (포커스 해제).
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        /// 키보드가 올라올 때 화면 크기가 조정되지 않도록 설정합니다.
        resizeToAvoidBottomInset: false,

        /// 다크 테마 배경색 (거의 검정에 가까운 어두운 회색)
        backgroundColor: const Color.fromRGBO(26, 26, 26, 1),
        body: Stack(
          children: [
            /// CustomScrollView를 사용하여 SliverAppBar와 SliverList를 함께 스크롤합니다.
            /// SliverAppBar는 스크롤 시 자연스럽게 축소/확장됩니다.
            CustomScrollView(
              slivers: [
                /// ─────────────────────────────────────────────────
                /// [SliverAppBar] - 상단 앱바
                /// ─────────────────────────────────────────────────
                /// "TODO with Hive" 타이틀과 Todo 추가 버튼(+)을 표시합니다.
                SliverAppBar(
                  backgroundColor: const Color.fromRGBO(26, 26, 26, 1),
                  title: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                        text: const TextSpan(
                            style: TextStyle(
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                fontSize: 24),
                            text: "TODO",
                            children: [
                          TextSpan(
                              text: " with Hive",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 24,
                                  color: Color.fromRGBO(155, 155, 155, 1))),
                        ])),
                  ),
                  actions: [
                    /// [Todo 추가 버튼] - 탭하면 빈 TodoEditWidget 시트를 엽니다.
                    GestureDetector(
                      onTap: () {
                        /// 햅틱 피드백 (진동)으로 사용자에게 터치 반응을 줍니다.
                        HapticFeedback.mediumImpact();

                        /// 새 Todo 생성을 위한 BottomSheet를 엽니다.
                        /// todo 파라미터를 전달하지 않으면 "생성" 모드로 동작합니다.
                        _showEditSheet();
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 12),
                        child: const Icon(
                          Icons.add_box_outlined,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  ],
                ),

                /// ─────────────────────────────────────────────────
                /// [SliverList] - Todo 목록 리스트
                /// ─────────────────────────────────────────────────
                /// ValueListenableBuilder로 _todos의 변경을 감지하여
                /// 목록이 변경될 때마다 자동으로 UI를 갱신합니다.
                ValueListenableBuilder(
                    valueListenable: _todos,
                    builder: (context, todos, child) {
                      return SliverList.builder(
                          itemCount: todos.length,
                          itemBuilder: (BuildContext context, int index) {
                            return TodoItemWidget(
                              /// 현재 인덱스의 Todo 데이터를 전달합니다.
                              todo: todos[index],

                              /// 아이템 탭: 수정을 위한 BottomSheet를 엽니다.
                              /// 기존 Todo를 전달하면 "수정" 모드로 동작합니다.
                              onTap: () => _showEditSheet(todo: todos[index]),

                              /// 체크박스 탭: 완료 상태를 토글합니다.
                              onChecked: (Todo todo) => _onChecked(todo, index),

                              /// 길게 누르기 후 삭제: 해당 Todo를 삭제합니다.
                              onDeleted: _onDeleted,
                            );
                          });
                    })
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// [_showEditSheet] - Todo 생성/수정을 위한 BottomSheet를 표시합니다.
  ///
  /// [매개변수]
  /// - todo: 수정할 기존 Todo 객체 (null이면 새 Todo 생성 모드)
  ///
  /// [동작 흐름]
  /// 1. showModalBottomSheet()로 TodoEditWidget을 표시
  /// 2. isScrollControlled: true로 전체 화면 크기의 시트를 허용
  /// 3. 사용자가 시트를 닫으면 .then(_updated)로 반환값을 _updated 메서드에 전달
  ///    - SAVE/CHANGE 버튼으로 닫으면: Todo 객체가 반환됨 → _updated에서 처리
  ///    - 뒤로가기/바깥 탭으로 닫으면: null이 반환됨 → _updated에서 무시
  Future<void> _showEditSheet({Todo? todo}) async {
    await showModalBottomSheet(
      context: context,
      builder: (context) => TodoEditWidget(
        update: todo,
      ),
      isScrollControlled: true,
    ).then(_updated);
  }
}
